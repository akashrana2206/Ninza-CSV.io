﻿using System;

namespace NinjaCsv.Internal.UnitTests.Stubs
{
    public class UnitTestAttribute : Attribute
    {
        
    }
}