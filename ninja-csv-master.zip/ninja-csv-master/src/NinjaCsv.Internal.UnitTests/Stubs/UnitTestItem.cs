﻿namespace NinjaCsv.UnitTests.Utility
{
    public class UnitTestItem
    {
        public int IntId { get; set; }

        public double DoubleId { get; set; }

        public decimal DecimalId { get; set; }

        public string StringId { get; set; }
    }
}