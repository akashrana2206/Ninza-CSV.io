﻿namespace NinjaCsv.UnitTests.Utility
{
    public static class UnitTestFilePath
    {
        public const string Empty = "TestCsvFiles/empty.csv";
    }
}