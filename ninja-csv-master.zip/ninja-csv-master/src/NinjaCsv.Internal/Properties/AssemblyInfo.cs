﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("NinjaCsv")]
[assembly: InternalsVisibleTo("NinjaCsv.UnitTests")]
[assembly: InternalsVisibleTo("NinjaCsv.Internal.UnitTests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]//for NSubstitute