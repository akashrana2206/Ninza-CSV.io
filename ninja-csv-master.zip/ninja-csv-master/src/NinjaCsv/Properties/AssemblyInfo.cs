﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("NinjaCsv.UnitTests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]